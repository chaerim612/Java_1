package pk12;

public class Bear extends Animal{

	String woong="웅담";
	
}
