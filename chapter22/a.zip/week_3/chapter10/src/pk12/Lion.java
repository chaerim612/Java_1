package pk12;

public class Lion extends Animal{
	
	String galgi="풍성!!";

}
