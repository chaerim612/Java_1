package pk12;

public class Spider extends Animal {
	
	String web="슉슉";

	@Override
	public int getEye() {
		
		return 6;
	}

	@Override
	public int getLeg() {
		
		return 8;
	}
	
	

}
