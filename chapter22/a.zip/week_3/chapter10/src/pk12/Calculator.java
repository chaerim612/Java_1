package pk12;

public class Calculator {
	
	double areaCircle(double r) {
		
		System.out.println("Calculator객체의 areaCircle() 실행됨");
		return 3.14159*r*r;
	}

}
