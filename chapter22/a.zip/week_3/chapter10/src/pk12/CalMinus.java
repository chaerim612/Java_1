package pk12;

public class CalMinus extends CalculatorExam{

	@Override
	public int getResult(int n1, int n2) {
		
		return n1-n2;
	}
	
	

}
