package pk12;

public class Animal {
	
	private int eye=2;
	private int leg=4;
	
	public int getEye() {
		return eye;
	}
	
	public int getLeg() {
		return leg;
	}

}
