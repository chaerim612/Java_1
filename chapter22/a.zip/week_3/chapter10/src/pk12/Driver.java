package pk12;

import test.Vehicle;

public class Driver {
	
	public void driver(Vehicle vehicle) {
		vehicle.run();
	}

}
