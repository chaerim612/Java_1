package pk13;

public abstract class HttpServlet {
	
	public abstract void service() ; //추상메서드

}
