package pk11;

public class SuperTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Paprika obj=new Paprika();
		
		obj.Set1("피망류", "여름", "노란파프리카");
		obj.Set3("빨강", 2000, "빨강파프리카");
		obj.Disp1();
		obj.Disp2();
		obj.Disp3();
		
	}

}
