package pk11;

public class InheritanceTest {

	public static void main(String[] args) {
		
		StrawBerry obj=new StrawBerry();
		
		obj.Set1("Berry류", "여름");
		obj.Set2("딸기", "소");
		obj.Set3("빨강", 5000);
		obj.Disp1();
		System.out.println("--------------");
		obj.Disp2();
		System.out.println("--------------");
		obj.Disp3();
	

	}

}
