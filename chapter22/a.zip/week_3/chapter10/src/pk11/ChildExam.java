package pk11;

public class ChildExam extends ParentExam{
	
	private String car="벤츠";

	public String getCar() {
		return car;
	}

	public void setCar(String car) {
		this.car = car;
	}
	
	
}
