package pk11;

public class ParentExam {
	
	private int money=2000000000;//부모의 재산
	private String str="신촌"; //부모의 부동산
	
	
	public int getMoney() {
		return money;
	}
	
	public void setMoney(int money) {
		this.money = money; //부모의 재산
	}
	
	public String getStr() {
		return str;
	}
	
	public void setStr(String str) {
		this.str = str; //부모의 부동산
	}
	
	

}
